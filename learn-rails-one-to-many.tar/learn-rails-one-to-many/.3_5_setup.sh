
cp app/views/destinations/.3_5_show.html.erb app/views/destinations/show.html.erb
