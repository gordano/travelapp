
cp app/views/destinations/.3_7_edit.html.erb app/views/destinations/edit.html.erb
