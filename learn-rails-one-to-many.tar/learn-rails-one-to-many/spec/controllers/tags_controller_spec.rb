require 'rails_helper'

RSpec.describe TagsController, :type => :controller do

end
