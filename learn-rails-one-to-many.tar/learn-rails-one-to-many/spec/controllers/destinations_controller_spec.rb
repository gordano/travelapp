require 'rails_helper'

RSpec.describe DestinationsController, :type => :controller do

end
