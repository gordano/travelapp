Rails.application.config.assets.precompile += %w( style.css )
