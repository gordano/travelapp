
# HTML for tags 

cp app/views/tags/.3_4_index.html.erb app/views/tags/index.html.erb


# CSS for all

cp app/assets/stylesheets/.3_4_application.css app/assets/stylesheets/application.css
