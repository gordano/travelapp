window.onload = function() {
  window.parent.postMessage({location:window.location.href}, "*");
};
