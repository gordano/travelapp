class Destination < ActiveRecord::Base
	belongs_to :tag
end
