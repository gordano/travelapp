class Tag < ActiveRecord::Base
	has_many :destinations
end
